#include "box.h"

Box::Box(QWidget *parent): QWidget(parent)
{
    srand((int)time(NULL));
    for(int x = 0; x < MAXX; x++)
        for(int y = 0; y < MAXY; y++)
            box[x][y] = 0;
    blocks.clear();

    setFixedSize(get_width(), get_height());
    setPalette(QPalette(Qt::gray));
    setAutoFillBackground(true);
    repaint();
}

void Box::init()
{
    srand((int)time(NULL));
    for(int x = 0; x < MAXX; x++)
        for(int y = 0; y < MAXY; y++)
            box[x][y] = 0;
    blocks.clear();

    repaint();
}

void Box::add_blocks_to_box()
{
    Block first = blocks.dequeue();
    for(int i = 0; i < COUNT; i++)
        box[first.x[i]][first.y[i]] = 1;
}

bool Box::can_exist(Block b)
{
    bool failed = false;
    for(int i = 0; i < COUNT; i++)
    {
        if(box[b.x[i]][b.y[i]] == 1 || b.y[i] >= MAXY ||
           b.x[i] < 0 || b.x[i] >= MAXX)
        {
            failed = true;
            break;
        }
    }
    if(failed) return false;
    else return true;
}

bool Box::is_end()
{
    for(int x = 0; x < MAXX; x++)
        if(box[x][0] == 1) return true;
    return false;
}

void Box::new_block(int kind)
{
    if(kind == 0)
        kind = (rand() % 5) + 1;
    Block new_block(kind);
    if(!blocks.isEmpty())
        blocks.back().is_dropping = 1;
    blocks.enqueue(new_block);
}

int Box::get_width()
{
    return WIDTH * MAXX + INTERVAL * (MAXX+1);
}

int Box::get_height()
{
    return HEIGHT * MAXY + INTERVAL * (MAXY+1);
}

bool Box::left()
{
    if(blocks.isEmpty()) return false;
    Block &first = blocks.head();
    if(!first.is_dropping) return false;
    Block new_block = first.move_left();
    if(can_exist(new_block))
    {
        first = new_block;
        repaint();
        return true;
    }
    else return false;
}

bool Box::right()
{
    if(blocks.isEmpty()) return false;
    Block &first = blocks.head();
    if(!first.is_dropping) return false;
    Block new_block = first.move_right();
    if(can_exist(new_block))
    {
        first = new_block;
        repaint();
        return true;
    }
    else return false;
}

bool Box::rotate()
{
    if(blocks.isEmpty()) return false;
    Block &first = blocks.head();
    if(!first.is_dropping) return false;
    Block new_block = first.rotate();
    if(can_exist(new_block))
    {
        first = new_block;
        repaint();
        return true;
    }
    else return false;
}


int Box::drop()
{
    if(blocks.isEmpty()) return false;
    Block &first = blocks.head();
    if(!first.is_dropping) return 0;
    Block new_block = first.drop();
    if(can_exist(new_block))
    {
        first = new_block;
        return 1;
    }
    else
    {
        if(is_end()) return -1;
        else return 0;
    }
}

int Box::drop_to_bottom()
{
    while(true)
    {
        int s = drop();
        if(s == -1) return -1;
        else if(s == 0) break;
    }
    return 1;
}

int Box::kill_lines()
{
    int res = 0;
    for(int y = MAXY-1; y >= 1;)
    {
        bool full = 1;
        for(int x = 0; x < MAXX; x++)
        {
            if(box[x][y] == 0)
            {
                full = 0;
                break;
            }
        }
        if(full)
        {
            res++;
            for(int y0 = y; y0 >= 1; y0--)
                for(int x = 0; x < MAXX; x++)
                    box[x][y0] = box[x][y0-1];
        }
        else y--;
    }
    repaint();
    return res;
}

bool Box::update_box()
{
    bool failed = false;
    int t = blocks.size();
    for(int i = 0; i < t; i++)
    {
        if(blocks.head().is_dropping == 0)
        {
            blocks.enqueue(blocks.dequeue());
            continue;
        }
        int s = drop();
        if(s == 1)
            blocks.enqueue(blocks.dequeue());
        else if(s == 0)
        {
            add_blocks_to_box();
        }
        else
        {
            failed = true;
            break;
        }
    }
    if(failed) return false;
    else
    {
        repaint();
        return true;
    }
}

void Box::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPen pen;
    pen.setColor(Qt::white);
    pen.setStyle(Qt::SolidLine);
    QBrush brush;
    brush.setColor(Qt::white);
    brush.setStyle(Qt::SolidPattern);
    painter.setPen(pen);
    painter.setBrush(brush);

    for(int x = 0; x < MAXX; x++)
        for(int y = 0; y < MAXY; y++)
            if(box[x][y] == 0)
            {
                int px = WIDTH * x + INTERVAL * (x+1);
                int py = HEIGHT * y + INTERVAL * (y+1);
                painter.drawRect(px, py, WIDTH, HEIGHT);
            }

    pen.setColor(Qt::black);
    pen.setStyle(Qt::SolidLine);
    brush.setColor(Qt::black);
    brush.setStyle(Qt::SolidPattern);
    painter.setPen(pen);
    painter.setBrush(brush);

    for(int x = 0; x < MAXX; x++)
        for(int y = 0; y < MAXY; y++)
            if(box[x][y] == 1)
            {
                int px = WIDTH * x + INTERVAL * (x+1);
                int py = HEIGHT * y + INTERVAL * (y+1);
                painter.drawRect(px, py, WIDTH, HEIGHT);
            }

    for(int i = 0; i < blocks.size(); i++)
    {
        Block &first = blocks.head();
        for(int j = 0; j < COUNT; j++)
        {
            int x = first.x[j], y = first.y[j];
            if(x < 0 || x >= MAXX || y < 0 || y >= MAXY) continue;
            int px = WIDTH * x + INTERVAL * (x+1);
            int py = HEIGHT * y + INTERVAL * (y+1);
            painter.drawRect(px, py, WIDTH, HEIGHT);
        }
        blocks.enqueue(blocks.dequeue());
    }
}
