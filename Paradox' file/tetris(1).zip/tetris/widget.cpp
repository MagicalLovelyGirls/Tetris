#include "widget.h"

Widget::Widget(QWidget *parent): QWidget(parent)
{
    score = 0;
    minute = second = 0;
    status = GAME_OFF;

    box = new Box;
    main_layout = new QGridLayout(this);
    timer_drop = new QTimer(this);
    timer_creat = new QTimer(this);
    timer_delay = new QTimer(this);
    timer_clock = new QTimer(this);
    label_difficult = new QLabel(tr("difficulty: "));
    label_score = new QLabel(tr("score: 0"));
    label_clock = new QLabel(tr("time: 0:0"));
    label_hint = new QLabel(tr("easy-1, normal-2, challenge-3"));

    this->resize(600, 800);
    main_layout->addWidget(box, 0, 0, 6, 1);
    main_layout->addWidget(label_difficult, 1, 1);
    main_layout->addWidget(label_score, 2, 1);
    main_layout->addWidget(label_clock, 3, 1);
    main_layout->addWidget(label_hint, 4, 1);

    connect(timer_drop, SIGNAL(timeout()), this, SLOT(drop()));
    connect(timer_creat, SIGNAL(timeout()), this, SLOT(creat()));
    connect(timer_delay, SIGNAL(timeout()), this, SLOT(delay()));
    connect(timer_clock, SIGNAL(timeout()), this, SLOT(clock()));
}

void Widget::init()
{
    score = 0;
    minute = second = 0;
    label_difficult->setText("difficulty: ");
    label_score->setText("score: 0");
    label_clock->setText("time: 0:0");
    label_hint->setText("easy-1, normal-2, challenge-3");
    box->init();
}

void Widget::new_block()
{
    QString str;
    str = in->readLine();
    if(!str.isNull())
    {
        char *ch;
        QByteArray ba = str.toLatin1();
        ch = ba.data();
        int kind = ch[str.size()-1] - '0';
        box->new_block(kind);
    }
    else box->new_block();
}

void Widget::start(int difficult)
{
    status = GAME_ON;
    difficulty = difficult;
    drop_interval = di[difficulty];
    creat_interval = ci[difficulty];
    if(difficulty == EASY)
    {
        file = new QFile("/Users/paradox/Desktop/tetris/testSet1/easy.txt");
        file->open(QIODevice::ReadOnly | QIODevice::Text);
        in = new QTextStream(file);
    }
    else if(difficulty == NORMAL)
    {
        file = new QFile("/Users/paradox/Desktop/tetris/testSet1/normal.txt");
        file->open(QIODevice::ReadOnly | QIODevice::Text);
        in = new QTextStream(file);
    }
    else if(difficulty == CHALLENGE)
    {
        file = new QFile("/Users/paradox/Desktop/tetris/testSet1/challenge.txt");
        file->open(QIODevice::ReadOnly | QIODevice::Text);
        in = new QTextStream(file);
    }
    new_block();
    new_block();

    QString str;
    if(difficulty == EASY) str += QString("difficulty: easy");
    else if(difficulty == NORMAL) str += QString("difficulty: normal");
    else if(difficulty == CHALLENGE) str += QString("difficulty: challenge");
    label_difficult->setText(str);

    label_hint->setText("easy-1, normal-2, challenge-3");

    timer_drop->start(drop_interval);
    timer_clock->start(1000);
    timer_delay->start(drop_interval/5);
}


void Widget::drop()
{
    if(status == GAME_ON)
    {
        box->update_box();
        score += (box->kill_lines()) * MAXX;
        QString str;
        str += QString("score: %1").arg(score);
        label_score->setText(str);
        if(box->is_end())
        {
            file->close();
            timer_drop->stop();
            timer_clock->stop();
            status = GAME_OVER;
            label_hint->setText("GameOver, again-Space");
        }
    }
}

void Widget::creat()
{
    if(status == GAME_ON)
        new_block();
}

void Widget::delay()
{
    timer_delay->stop();
    timer_creat->start(creat_interval);
}

void Widget::clock()
{
    second++;
    if(second == 60)
    {
        second = 0;
        minute++;
    }
    QString str;
    str += QString("time: %1").arg(minute);
    str += QString(":%1").arg(second);
    label_clock->setText(str);
}

void Widget::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_A)
    {
        if(status == GAME_ON)
            box->left();
    }
    else if(event->key() == Qt::Key_D)
    {
        if(status == GAME_ON)
            box->right();
    }
    else if(event->key() == Qt::Key_W)
    {
        if(status == GAME_ON)
            box->rotate();
    }
    else if(event->key() == Qt::Key_S)
    {
        if(status == GAME_ON)
            box->drop_to_bottom();
    }
    else if(event->key() == Qt::Key_Space)
    {
        if(status == GAME_OVER)
        {
            init();
            status = GAME_OFF;
        }
    }
    else if(event->key() == Qt::Key_1)
    {
        if(status == GAME_OFF)
            start(EASY);
        label_hint->setText("left-A, right-B, rotate-W, drop-S");
    }
    else if(event->key() == Qt::Key_2)
    {
        if(status == GAME_OFF)
            start(NORMAL);
        label_hint->setText("left-A, right-B, rotate-W, drop-S");
    }
    else if(event->key() == Qt::Key_3)
    {
        if(status == GAME_OFF)
            start(CHALLENGE);
        label_hint->setText("left-A, right-B, rotate-W, drop-S");
    }
}
